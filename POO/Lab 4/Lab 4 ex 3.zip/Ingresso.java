public class Ingresso {

    private int valor;

    public int getValor() {
        return valor;
    }
    public void setValor(int valor){
        this.valor;

    }
    public void escrevalor (int valores){
        this.valor = valores;
        System.out.println("Valor do ingresso eh" + valores);
    }
}
